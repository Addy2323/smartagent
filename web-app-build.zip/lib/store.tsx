"use client"

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import {
  agents as seedAgents,
  cashEntries as seedCash,
  commissionFor,
  commissionTiers as seedTiers,
  debts as seedDebts,
  expenseCategories as seedCategories,
  expenses as seedExpenses,
  floatTopups as seedTopups,
  networks as seedNetworks,
  transactions as seedTransactions,
} from "./seed"
import type {
  Agent,
  CashDirection,
  CashEntry,
  CommissionTier,
  Debt,
  DebtKind,
  Expense,
  ExpenseCategory,
  FloatTopup,
  Network,
  Role,
  Transaction,
  TxType,
} from "./types"

const SEED_CASH_BALANCE = 2_350_000

let idCounter = 0
function uid(prefix: string) {
  idCounter += 1
  return `${prefix}-${Date.now().toString(36)}-${idCounter}`
}

interface NewTransactionInput {
  type: TxType
  networkId: string
  amount: number
  customer: string
  customerPhone: string
}

interface DataContextValue {
  // identity
  role: Role
  setRole: (r: Role) => void
  currentAgent: Agent
  agents: Agent[]
  // data
  networks: Network[]
  commissionTiers: CommissionTier[]
  transactions: Transaction[]
  floatTopups: FloatTopup[]
  cashEntries: CashEntry[]
  expenses: Expense[]
  expenseCategories: ExpenseCategory[]
  debts: Debt[]
  cashBalance: number
  // helpers
  networkById: (id: string) => Network | undefined
  agentById: (id: string) => Agent | undefined
  previewCommission: (type: TxType, networkId: string, amount: number) => number
  // actions
  addTransaction: (input: NewTransactionInput) => void
  addFloatTopup: (input: { networkId: string; amount: number; source: string; note: string; fromCash: boolean }) => void
  addCashEntry: (input: { direction: CashDirection; amount: number; reason: string }) => void
  addExpense: (input: { categoryId: string; amount: number; description: string }) => void
  addDebt: (input: { kind: DebtKind; party: string; partyPhone: string; principal: number; description: string; dueDate: string }) => void
  addDebtPayment: (debtId: string, amount: number) => void
  // settings (super admin)
  addNetwork: (input: { name: string; code: string; floatBalance: number; threshold: number }) => void
  updateNetworkThreshold: (id: string, threshold: number) => void
  addExpenseCategory: (name: string) => void
  updateTier: (id: string, field: "deposit" | "withdrawal", value: number) => void
}

const DataContext = createContext<DataContextValue | null>(null)

export function DataProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>("super_admin")
  const [agents] = useState<Agent[]>(seedAgents)
  const [networks, setNetworks] = useState<Network[]>(seedNetworks)
  const [commissionTiers, setCommissionTiers] = useState<CommissionTier[]>(seedTiers)
  const [transactions, setTransactions] = useState<Transaction[]>(seedTransactions)
  const [floatTopups, setFloatTopups] = useState<FloatTopup[]>(seedTopups)
  const [cashEntries, setCashEntries] = useState<CashEntry[]>(seedCash)
  const [expenses, setExpenses] = useState<Expense[]>(seedExpenses)
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>(seedCategories)
  const [debts, setDebts] = useState<Debt[]>(seedDebts)
  const [cashBalance, setCashBalance] = useState<number>(SEED_CASH_BALANCE)

  const currentAgent = useMemo(
    () => agents.find((a) => a.role === role) ?? agents[0],
    [agents, role],
  )

  const networkById = useCallback((id: string) => networks.find((n) => n.id === id), [networks])
  const agentById = useCallback((id: string) => agents.find((a) => a.id === id), [agents])

  const previewCommission = useCallback(
    (type: TxType, networkId: string, amount: number) =>
      commissionFor(commissionTiers, networkId, type, amount),
    [commissionTiers],
  )

  const addTransaction = useCallback(
    (input: NewTransactionInput) => {
      const commission = commissionFor(commissionTiers, input.networkId, input.type, input.amount)
      const tx: Transaction = {
        id: uid("tx"),
        ref: `TXN${Math.floor(100000 + Math.random() * 899999)}`,
        type: input.type,
        networkId: input.networkId,
        amount: input.amount,
        commission,
        customer: input.customer,
        customerPhone: input.customerPhone,
        agentId: currentAgent.id,
        createdAt: new Date().toISOString(),
      }
      setTransactions((prev) => [tx, ...prev])
      // deposit (cash-in): agent receives cash, e-float drops
      // withdrawal (cash-out): agent pays cash, e-float rises
      setNetworks((prev) =>
        prev.map((n) =>
          n.id === input.networkId
            ? { ...n, floatBalance: n.floatBalance + (input.type === "deposit" ? -input.amount : input.amount) }
            : n,
        ),
      )
      setCashBalance((c) => c + (input.type === "deposit" ? input.amount : -input.amount))
    },
    [commissionTiers, currentAgent.id],
  )

  const addFloatTopup = useCallback(
    (input: { networkId: string; amount: number; source: string; note: string; fromCash: boolean }) => {
      const topup: FloatTopup = {
        id: uid("ft"),
        networkId: input.networkId,
        amount: input.amount,
        source: input.source,
        note: input.note,
        agentId: currentAgent.id,
        createdAt: new Date().toISOString(),
      }
      setFloatTopups((prev) => [topup, ...prev])
      setNetworks((prev) =>
        prev.map((n) => (n.id === input.networkId ? { ...n, floatBalance: n.floatBalance + input.amount } : n)),
      )
      if (input.fromCash) setCashBalance((c) => c - input.amount)
    },
    [currentAgent.id],
  )

  const addCashEntry = useCallback(
    (input: { direction: CashDirection; amount: number; reason: string }) => {
      const entry: CashEntry = {
        id: uid("ce"),
        direction: input.direction,
        amount: input.amount,
        reason: input.reason,
        agentId: currentAgent.id,
        createdAt: new Date().toISOString(),
      }
      setCashEntries((prev) => [entry, ...prev])
      setCashBalance((c) => c + (input.direction === "in" ? input.amount : -input.amount))
    },
    [currentAgent.id],
  )

  const addExpense = useCallback(
    (input: { categoryId: string; amount: number; description: string }) => {
      const expense: Expense = {
        id: uid("ex"),
        categoryId: input.categoryId,
        amount: input.amount,
        description: input.description,
        agentId: currentAgent.id,
        createdAt: new Date().toISOString(),
      }
      setExpenses((prev) => [expense, ...prev])
      setCashBalance((c) => c - input.amount)
    },
    [currentAgent.id],
  )

  const addDebt = useCallback(
    (input: { kind: DebtKind; party: string; partyPhone: string; principal: number; description: string; dueDate: string }) => {
      const debt: Debt = {
        id: uid("debt"),
        kind: input.kind,
        party: input.party,
        partyPhone: input.partyPhone,
        principal: input.principal,
        description: input.description,
        payments: [],
        agentId: currentAgent.id,
        createdAt: new Date().toISOString(),
        dueDate: input.dueDate,
      }
      setDebts((prev) => [debt, ...prev])
    },
    [currentAgent.id],
  )

  const addDebtPayment = useCallback((debtId: string, amount: number) => {
    setDebts((prev) =>
      prev.map((d) =>
        d.id === debtId
          ? { ...d, payments: [...d.payments, { id: uid("dp"), amount, createdAt: new Date().toISOString() }] }
          : d,
      ),
    )
  }, [])

  const addNetwork = useCallback(
    (input: { name: string; code: string; floatBalance: number; threshold: number }) => {
      const id = uid("net")
      setNetworks((prev) => [...prev, { id, name: input.name, code: input.code, floatBalance: input.floatBalance, threshold: input.threshold, active: true }])
    },
    [],
  )

  const updateNetworkThreshold = useCallback((id: string, threshold: number) => {
    setNetworks((prev) => prev.map((n) => (n.id === id ? { ...n, threshold } : n)))
  }, [])

  const addExpenseCategory = useCallback((name: string) => {
    setExpenseCategories((prev) => [...prev, { id: uid("cat"), name }])
  }, [])

  const updateTier = useCallback((id: string, field: "deposit" | "withdrawal", value: number) => {
    setCommissionTiers((prev) => prev.map((t) => (t.id === id ? { ...t, [field]: value } : t)))
  }, [])

  const value: DataContextValue = {
    role,
    setRole,
    currentAgent,
    agents,
    networks,
    commissionTiers,
    transactions,
    floatTopups,
    cashEntries,
    expenses,
    expenseCategories,
    debts,
    cashBalance,
    networkById,
    agentById,
    previewCommission,
    addTransaction,
    addFloatTopup,
    addCashEntry,
    addExpense,
    addDebt,
    addDebtPayment,
    addNetwork,
    updateNetworkThreshold,
    addExpenseCategory,
    updateTier,
  }

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}

export function useData() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error("useData must be used within DataProvider")
  return ctx
}
