"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  ArrowLeftRight,
  Banknote,
  Coins,
  FileBarChart,
  HandCoins,
  LayoutDashboard,
  Receipt,
  Settings,
  TrendingUp,
  Wallet,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useData } from "@/lib/store"

const operations = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Transactions", url: "/transactions", icon: ArrowLeftRight },
  { title: "Commissions", url: "/commissions", icon: HandCoins },
]

const treasury = [
  { title: "Float", url: "/float", icon: Wallet },
  { title: "Cash", url: "/cash", icon: Banknote },
]

const finance = [
  { title: "Expenses", url: "/expenses", icon: Receipt },
  { title: "Debts", url: "/debts", icon: Coins },
  { title: "Profit & Loss", url: "/profit-loss", icon: TrendingUp },
  { title: "Reports", url: "/reports", icon: FileBarChart },
]

function NavSection({
  label,
  items,
  pathname,
}: {
  label: string
  items: { title: string; url: string; icon: typeof LayoutDashboard }[]
  pathname: string
}) {
  return (
    <SidebarGroup>
      <SidebarGroupLabel>{label}</SidebarGroupLabel>
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => (
            <SidebarMenuItem key={item.url}>
              <SidebarMenuButton
                isActive={pathname === item.url}
                tooltip={item.title}
                render={
                  <Link href={item.url}>
                    <item.icon className="size-4" />
                    <span>{item.title}</span>
                  </Link>
                }
              />
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

export function AppSidebar() {
  const pathname = usePathname()
  const { role, currentAgent } = useData()

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2 px-1 py-1.5">
          <div className="flex size-8 shrink-0 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
            <TrendingUp className="size-4" />
          </div>
          <div className="grid leading-tight group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-semibold">SmartAgent</span>
            <span className="text-xs text-sidebar-foreground/60">Manager</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <NavSection label="Operations" items={operations} pathname={pathname} />
        <NavSection label="Treasury" items={treasury} pathname={pathname} />
        <NavSection label="Finance" items={finance} pathname={pathname} />
        {role === "super_admin" && (
          <NavSection
            label="Admin"
            items={[{ title: "Settings", url: "/settings", icon: Settings }]}
            pathname={pathname}
          />
        )}
      </SidebarContent>
      <SidebarFooter>
        <div className="flex items-center gap-2 px-1 py-1.5">
          <Avatar className="size-8">
            <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground text-xs">
              {currentAgent.name
                .split(" ")
                .map((p) => p[0])
                .join("")
                .slice(0, 2)}
            </AvatarFallback>
          </Avatar>
          <div className="grid leading-tight group-data-[collapsible=icon]:hidden">
            <span className="truncate text-sm font-medium">{currentAgent.name}</span>
            <span className="truncate text-xs text-sidebar-foreground/60">
              {role === "super_admin" ? "Super Admin" : "Agent"}
            </span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
