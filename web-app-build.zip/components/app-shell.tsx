"use client"

import { usePathname } from "next/navigation"
import { ShieldCheck, UserRound } from "lucide-react"
import { AppSidebar } from "@/components/app-sidebar"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { useData } from "@/lib/store"
import { cn } from "@/lib/utils"

const titles: Record<string, string> = {
  "/": "Dashboard",
  "/transactions": "Transactions",
  "/commissions": "Commissions",
  "/float": "Float Management",
  "/cash": "Cash Management",
  "/expenses": "Expenses",
  "/debts": "Debts",
  "/profit-loss": "Profit & Loss",
  "/reports": "Reports",
  "/settings": "Settings",
}

function RoleSwitcher() {
  const { role, setRole } = useData()
  return (
    <div className="flex items-center rounded-lg border bg-card p-0.5">
      <Button
        size="sm"
        variant="ghost"
        onClick={() => setRole("super_admin")}
        className={cn(
          "h-7 gap-1.5 px-2.5 text-xs",
          role === "super_admin" && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground",
        )}
      >
        <ShieldCheck className="size-3.5" />
        <span className="hidden sm:inline">Super Admin</span>
      </Button>
      <Button
        size="sm"
        variant="ghost"
        onClick={() => setRole("agent")}
        className={cn(
          "h-7 gap-1.5 px-2.5 text-xs",
          role === "agent" && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground",
        )}
      >
        <UserRound className="size-3.5" />
        <span className="hidden sm:inline">Agent</span>
      </Button>
    </div>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const title = titles[pathname] ?? "SmartAgent Manager"

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-14 shrink-0 items-center gap-2 border-b bg-background/95 px-4 backdrop-blur">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-1 h-4" />
          <h1 className="text-base font-semibold text-balance">{title}</h1>
          <div className="ml-auto">
            <RoleSwitcher />
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-6 p-4 md:p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
